<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/index.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio da recuperação</title>
</head>
<body>
    <div class="container">
    
        <div class="txt">
            <h1>Sistema de gerenciamento - SENAI</h1>
            <p>O sistema utilizado por todas as unidades do senai em todo o Brasil, utilizada por mais de 5.000.000 de alunos.</p>
        </div>

        <div class="botao">

            <div class="adm">
                <h1>Administrador</h1>
                <label for="botao1"><p>Acesse a aplicação como adminsitrador.</p></label>
                <a href="sys/admin.php" name="botao1"><button>login</button></a>
            </div>

            <div class="adm">
                <h1>Professor</h1>
                <label for="botao2"><p>Acesse a aplicação como professor.</p></label>
                <a href="sys/admin.php" name="botao2"><button>login</button></a>
            </div>

            <div class="adm">
                <h1>Aluno</h1>
                <label for="botao3"><p>Acesse a aplicação como aluno.</p></label>
                <a href="sys/admin.php" name="botao3"><button>login</button></a>
            </div>

        </div>
    </div>
</body>
</html>