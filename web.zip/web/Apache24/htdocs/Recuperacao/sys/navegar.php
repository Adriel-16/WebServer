<?php
    session_start();

    if ($_SESSION["logado"] == FALSE) {
        header("Location: ../index.php");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

            <div class="container">

                <div class="botoes_laterais">
                    <div class="sair">
                        <a href="logoff.php" name="sair">
                            <button>sair</button>
                        </a>
                    </div>

                    <div class="add">
                        <a href="Cadaluno.php"><button>Adicionar Aluno</button></a>
                    </div>
                </div>

                <dialog id="modal" open>
                    <div class="container2">
                        <div class="pesquisar">
                            <form method="post" action="navegar.php">
                                <input type="text" class="pesquisarin" id="pesqusiarin" name="pesquisar2" placeholder="Pesquisar Contato">
                                <button id="btao2" class="btao2" type="submit" name="pesquisar3">Pesquisar Aluno</button>
                                
                            </form>
                                <div class="contatos">
                               
                                <?php

                                    extract($_POST);
                                    if(isset($_POST['pesquisar3']))
                                    {
                                        include_once("class/connect.php");
                                        $obj = new connect();
                                        $resultado = $obj->conectarBanco();
                                        $indice = 0;
                                        $sql = "SELECT * FROM Contatos WHERE nome like'".$_POST['pesquisar2']."%';";

                                        $query = $resultado->prepare($sql);
                                        if($query->execute())
                                        {
                                            while($linha = $query->fetch(PDO::FETCH_ASSOC))
                                            {
                                                $linhas[$indice] = $linha;
                                                $indice++;  
                                            }
                                        }

                                        if($indice > 0){
                                            echo'<table class="table1">';
                                            echo'
                                                <tr>
                                                    <td>Nome</td>
                                                    <td>Turma</td>
                                                    <td>email</td>
                                                    <td>telefone</td>
                                                </tr>
                                            ';
                                            for($i = 0; $i<$indice; $i++){
                                                echo '
                                                    <tr>
                                                        <td>'.$linhas[$i]['nome'].'</td>
                                                        <td>'.$linhas[$i]['turma'].'</td>
                                                        <td>'.$linhas[$i]['idade'].'</td>
                                                        <td>'.$linhas[$i]['endereco'].'</td>
                                                        <td>
                                                            <form action="delete.php" method="POST">
                                                                <input type="hidden" name="id_cont" value="' . $linhas[$i]['id_cont'] . '">
                                                                <input  type="submit" name="delete" value="delete">
                                                            </form>
                                                        </td>
                                                            <td>
                                                                <a href="editar.php?id_cont='.$linhas[$i]['id_cont'].'"><input type="button" name="editar"  value="editar"></a>
                                                            </td>
                                                    </tr>
                                                ';
                                            }
                                            echo "</table>";
                                        } else {
                                            echo "Nenhum contato encontrado.";
                                        }
                                    }
                                    ?>
                            </div>
                        </div>
                    </div>
                </dialog>
                
            </div>
</body>
</html>