<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/cadastro.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
</head>
<body>
    <div class="container">
        

            <div class="txt">
                <h1>Cadastro</h1>
            </div>
            <a href="navegar.php"><button>voltar</button></a>
        <form action="cadastro.php" method="post">
            <table>
                <tr>
                    <td><input type="text" id="nome" name="name" required placeholder="  Nome"></td>
                </tr>
                <tr>
                    <td><input type="email" id="email" name="email" required placeholder="  Email"></td>
                </tr>
                <tr>
                    <td><input type="password" id="senha" name="password" required placeholder="  Senha"></td>
                </tr>
            </table>
            <table>
                <tr>
                    <td><button id="button" type="submit" name="cadastro">Cadastrar</button></td>
                </tr>
            </table>

        </form>
    </div>
</body>
</html>

<?php

    if (isset($_POST["cadastro"])) {
        include_once("class/connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $nomeUsuario = htmlspecialchars($_POST["name"]);
        $email = htmlspecialchars($_POST["email"]);
        $senhacriptografada = md5($_POST["password"]);

        $checkLoginSql = "SELECT * FROM Usuario WHERE email = :email";
        $checkQuery = $resultado->prepare($checkLoginSql);
        $checkQuery->execute(['email' => $email]);
        $loginExists = $checkQuery->fetchColumn();

        if ($loginExists) {
            echo '<script type="text/javascript">alert("O email já está em uso. Tente outro.");</script>';
        } else {
        
            $sql = "INSERT INTO Usuario (nome, email, passwrd, ativo) VALUES (:nome, :email, :senha, TRUE)";
            $query = $resultado->prepare($sql);
            $query->bindParam(':nome', $nomeUsuario);
            $query->bindParam(':email', $email);
            $query->bindParam(':senha', $senhacriptografada);
            
            if ($query->execute()) {
                echo '<script type="text/javascript">alert("Cadastro realizado com sucesso!");</script>';
            } else {
                echo "Erro ao cadastrar, tente novamente!";
            }
        }
    }
?>
