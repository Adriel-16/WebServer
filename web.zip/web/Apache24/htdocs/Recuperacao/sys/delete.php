<?php

    include_once("class/connect.php");
    $obj = new connect();
    $conexao = $obj->conectarBanco();

    extract($_POST);

    if (!empty($_POST['id_cont'])) {
        $id = $_POST['id_cont'];

        $sqlDelete = "DELETE FROM Contatos WHERE id_cont = '$id'";
        $query = $conexao->query($sqlDelete);
        

        if ($query->execute()) {
            echo'
                <script>
                    alert("Contato Deletado");
                </script>';
        }else{

            echo'
                <script>
                    alert("Não foi possivel exlcuir o contato");
                </script>';
             
        }
    }

    header("Location: navegar.php");

?>