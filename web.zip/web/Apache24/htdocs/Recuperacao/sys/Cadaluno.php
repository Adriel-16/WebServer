<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="fundo">
    <div class="sair">
        <a href="navegar.php" name="sair"><button>voltar</button></a>
    </div>
    
    <form action="Cadaluno.php" method="post">
        <div class="tabela">
            <div class="login">
                <h1>Adicionar aluno à turma</h1>
            </div>
            <table>
                <tr>
                    <td><input type="text" id="nome" name="name" required placeholder="  Nome"></td>
                </tr>
                <tr>
                    <td><input type="text" id="email" name="turma" required placeholder="  turma"></td>
                </tr>
                <tr>
                    <td><input type="email" id="telefone" name="idade" required placeholder="  email"></td>
                </tr>
                <tr>
                    <td><input type="number" id="endereco" name="endereco" required placeholder="  telefone"></td>
                </tr>
            </table>
        </div>
        <div class="botao">
            <table>
                <tr>
                    <td><button id="button" type="submit" name="cadastro" value="cadastro">Cadastrar</button></td>
                </tr>
            </table>
        </div>
    </form>
</div>
</body>
</html>

<?php
if (isset($_POST["cadastro"])) {
    include_once("class/connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    // Garantir que os valores não sejam null
    $nomeUsuario = isset($_POST["name"]) ? htmlspecialchars($_POST["name"]) : '';
    $idade = isset($_POST["idade"]) ? htmlspecialchars($_POST["idade"]) : '';
    $turma = isset($_POST["turma"]) ? htmlspecialchars($_POST["turma"]) : '';
    $endereco = isset($_POST["endereco"]) ? htmlspecialchars($_POST["endereco"]) : '';

    // Verificar se todos os campos necessários foram preenchidos
    if ($nomeUsuario && $idade && $turma && $endereco) {
        // Utilizando prepared statement para evitar SQL injection
        $sql = "INSERT INTO Contatos (nome, idade, turma, endereco, usuario_id) 
                VALUES (:nome, :idade, :turma, :endereco, :usuario_id)";
        
        $query = $resultado->prepare($sql);
        
        // Bind dos parâmetros
        $query->bindParam(':nome', $nomeUsuario);
        $query->bindParam(':idade', $idade);
        $query->bindParam(':turma', $turma);
        $query->bindParam(':endereco', $endereco);
        $query->bindParam(':usuario_id', $_SESSION["id"]);
        
        // Executar a query
        if ($query->execute()) {
            // Limpar os dados do formulário
            $_POST = [];
            echo '<script type="text/javascript">
                alert("Aluno adicionado com sucesso!");
                window.location.href = "navegar.php";
              </script>';
        } else {
            echo '<script type="text/javascript">alert("Não foi possível realizar o cadastro!");</script>';
        }
    } else {
        echo '<script type="text/javascript">alert("Por favor, preencha todos os campos!");</script>';
    }
}
?>
