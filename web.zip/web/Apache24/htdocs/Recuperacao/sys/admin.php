<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/adm.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="admin.php" method="post">
        <div class="container">
            <div class="txt">
                <h1>Logar no sistema</h1>
            </div>
            <div class="entradas">
            <table>
                    <tr>
                        <td><input type="email" name="name" required placeholder="  E-mail"></td>
                    </tr>
                    <tr>
                        <td><input type="password" name="passwrd" required placeholder="  Senha"></td>
                    </tr>
                </table>
                <div class="botoes">
                    <table>
                        <tr>
                            <td><button class="login" name="btnLogin" type="submit">Login</button></td>
                        </tr>
                    </table>
            </div>
            <div class="cadastro">
                    <a href="cadastro.php"><button type="button" class="cadastro" name="cad">Cadastre-se</button></a>
            </div>
        </div>
    </form>
</body>
</html>

<?php
    extract($_POST);

    if(isset($_POST["btnLogin"])){

        include_once("class/connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $emailUsuario = ($_POST["name"]);
        $usuariocriptografado = md5($_POST["passwrd"]);


        $sql = "SELECT * FROM Usuario WHERE email = '".$emailUsuario."' AND passwrd = '".$usuariocriptografado."';";

        $query = $resultado->prepare($sql);
		$indice = 0;
		if($query->execute())
        {
            while($linha = $query->fetch(PDO::FETCH_ASSOC))
			{
				$linhas[$indice] = $linha;
                $indice++;  
            }

            if ($indice == 1)
            {
                $_SESSION["logado"] = TRUE;
                $_SESSION["id"] = $linhas[0]['id'];
                header("Location: navegar.php");
                
           }
        }
    }
?>