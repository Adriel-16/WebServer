<?php

    session_start();

    if ($_SESSION["logado"] == FALSE) {
        header("Location: ../index.php");
        exit();
    }

    include_once("class/connect.php");
    $obj = new connect();
    $resultado = $obj->conectarBanco();



    $id = $_GET['id_cont'];
    $indice = 0;
    $sql = "SELECT * FROM Contatos where id_cont = ".$id.";";
    $query = $resultado->prepare($sql);

    if($query->execute())
    {
        while($linha = $query->fetch(PDO::FETCH_ASSOC))
        {
            $linhas[$indice] = $linha;
            $indice++;  
        }


        $nome = $linhas[0]['nome'];
        $email = $linhas[0]['email'];
        $telefone = $linhas[0]['telefone'];
        $endereco = $linhas[0]['endereco'];
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/editar.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<div class="fundo">
    <div class="sair">
        <a href="navegar.php" name="sair">
            <img src="css/img/voltar.png" width="50px" alt="Sair">
        </a>
        <label for="sair">Voltar</label>
    </div>
    
    <form action="editar.php?id_cont=<?=$_GET['id_cont'];?>" method="post">
        <div class="tabela">
            <div class="login">
                <h1>Editar Contato</h1>
            </div>
            <table>
                <tr>
                    <td><input type="text" id="nome" name="name" value="<?=$linhas[0]['nome']?>" required placeholder="  Nome"></td>
                </tr>
                <tr>
                    <td><input type="email" id="email" name="email" value="<?=$linhas[0]['email']?>" required placeholder="  Email"></td>
                </tr>
                <tr>
                    <td><input type="text" id="telefone" name="celular" value="<?=$linhas[0]['telefone']?>" required placeholder="  Telefone"></td>
                </tr>
                <tr>
                    <td><input type="text" id="endereco" name="endereco" value="<?=$linhas[0]['endereco']?>" required placeholder="  Endereço"></td>
                </tr>
            </table>
        </div>
        <div class="botao">
            <table>
                <tr>
                    <td><button id="button" type="submit" name="editar" value="editar">Editar</button></td>
                </tr>
            </table>
        </div>
    </form>
</div>
</body>
</html>
<?php

$id = $_GET['id_cont'];
extract($_POST);

if(isset($_POST["editar"])){
    $nome = $_POST['name'];
    $email = $_POST['email'];
    $telefone = $_POST['celular'];
    $endereco = $_POST['endereco'];

     $sqlUpdate = "UPDATE Contatos SET nome = '".$nome."', email = '".$email."', telefone = '".$telefone."', endereco = '".$endereco."' WHERE id_cont = ".$id.";";
    $query = $resultado->prepare($sqlUpdate);

    if($query->execute())
    {
        echo 'OK';
    }

}
?>