<?php
session_start();

if ($_SESSION["logado"] == FALSE) {
    header("Location: ../index.php");
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="css/navegar.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
</head>

<body>
    <header>
        <!--<form action="navegar.php" method="post">-->
            <div class="container">

                <div class="sair">
                    <a href="logoff.php" name="sair">
                        <img src="css/img/logout.png" width="50px" alt="Sair">
                    </a>
                    <label for="sair">Sair</label>
                </div>

                <div class="add">
                    <a href="contato.php"><img src="css/img/add.png" height="70px" name="cntt"></a>
                    <label for="cntt">Adicionar contato</label>
                </div>

                <div class="lista">
                    <button id="listar" class="btao" name="lista"><img src="css/img/lista.png" height="70px" name="lista"></button>
                    <label for="lista">Listar Contatos</label>
                </div>

                <dialog id="modal" open>
                    <div class="container2">
                        <div class="pesquisar">
                            <form method="post" action="navegar.php">
                                <input type="text" class="pesquisarin" id="pesqusiarin" name="pesquisar2" placeholder="Pesquisar Contato">
                                <button id="btao2" class="btao2" type="submit" name="pesquisar3"><img src="css/img/lupa.png" height="70px" name="pesquisa"></button>
                                
                            </form>
                                <div class="contatos">
                                <!--<form action="navegar.php" method="post">-->
                                <?php

                                    extract($_POST);
                                    if(isset($_POST['pesquisar3']))
                                    {
                                        include_once("class/connect.php");
                                        $obj = new connect();
                                        $resultado = $obj->conectarBanco();
                                        $indice = 0;
                                        $sql = "SELECT * FROM Contatos WHERE nome like'".$_POST['pesquisar2']."%';";

                                        $query = $resultado->prepare($sql);
                                        if($query->execute())
                                        {
                                            while($linha = $query->fetch(PDO::FETCH_ASSOC))
                                            {
                                                $linhas[$indice] = $linha;
                                                $indice++;  
                                            }
                                        }

                                        if($indice > 0){
                                            echo'<table class="table1">';
                                            echo'
                                                <tr>
                                                    <td>Nome</td>
                                                    <td>Telefone</td>
                                                    <td>Email</td>
                                                    <td>endereco</td>
                                                </tr>
                                            ';
                                            for($i = 0; $i<$indice; $i++){
                                                echo '
                                                    <tr>
                                                        <td>'.$linhas[$i]['nome'].'</td>
                                                        <td>'.$linhas[$i]['telefone'].'</td>
                                                        <td>'.$linhas[$i]['email'].'</td>
                                                        <td>'.$linhas[$i]['endereco'].'</td>
                                                        <td>
                                                            <form action="delete.php" method="POST">
                                                                <input type="hidden" name="id_cont" value="' . $linhas[$i]['id_cont'] . '">
                                                                <input  type="submit" name="delete" value="delete">
                                                            </form>
                                                        </td>
                                                            <td>
                                                                <a href="editar.php?id_cont='.$linhas[$i]['id_cont'].'"><input type="button" name="editar"  value="editar"></a>
                                                            </td>
                                                    </tr>
                                                ';
                                            }
                                            echo "</table>";
                                        } else {
                                            echo "Nenhum contato encontrado.";
                                        }
                                    }
                                    ?>
                                <!--</form>-->
                            </div>
                        </div>
                        <div class="fechar">
                            <button id="fechar2" class="btao3">Fechar lista</button>
                        </div>
                    </div>
                </dialog>
                
            </div>

        <!--</form>-->
    </header>
</body>

<script src="js/listar.js"></script>
</html>