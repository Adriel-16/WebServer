<?php
	session_start();
?>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/cadastro.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Contato</title>
</head>
<body>

<div class="fundo">
    <div class="sair">
        <a href="navegar.php" name="sair">
            <img src="css/img/logout.png" width="50px" alt="Sair">
        </a>
        <label for="sair">Voltar</label>
    </div>
    
    <form action="contato.php" method="post">
        <div class="tabela">
            <div class="login">
                <h1>Cadastro de Contato</h1>
            </div>
            <table>
                <tr>
                    <td><input type="text" id="nome" name="name" required placeholder="  Nome"></td>
                </tr>
                <tr>
                    <td><input type="email" id="email" name="email" required placeholder="  Email"></td>
                </tr>
                <tr>
                    <td><input type="text" id="telefone" name="celular" required placeholder="  Telefone"></td>
                </tr>
                <tr>
                    <td><input type="text" id="endereco" name="endereco" required placeholder="  Endereço"></td>
                </tr>
            </table>
        </div>
        <div class="botao">
            <table>
                <tr>
                    <td><button id="button" type="submit" name="cadastro" value="cadastro">Cadastrar</button></td>
                </tr>
            </table>
        </div>
    </form>
</div>
</body>
</html>

<?php

    if (isset($_POST["cadastro"])) {
        include_once("class/connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();

        $nomeUsuario = htmlspecialchars($_POST["name"]);
        $email = htmlspecialchars($_POST["email"]);
        $telefone = htmlspecialchars($_POST["celular"]);
        $endereco = htmlspecialchars($_POST["endereco"]);

        $sql = "INSERT INTO Contatos (nome, email, telefone, endereco, usuario_id) VALUES ('".$nomeUsuario."', '".$email ."', '".$telefone."', '".$endereco."', ".$_SESSION["id"].");";
        $query = $resultado->prepare($sql);
        if($query->execute()){

            $_POST = []  ;
            echo '<script type="text/javascript">
            alert("Contato feito com sucesso!");
            window.location.href = "navegar.php";
          </script>';

            }else{

                echo '<script type="text/javascript">alert("Não foi possivel realizar o cadastro!");</script>';

            }
        }
?>