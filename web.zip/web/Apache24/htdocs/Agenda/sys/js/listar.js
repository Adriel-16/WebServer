const button = document.querySelector("#listar");
const button2 = document.querySelector("#fechar2");
const modal = document.querySelector("#modal");
const searchButton = document.getElementById(".btao2"); // Botão de pesquisa


button.onclick = function(event) {
    event.preventDefault();
    modal.show();
}

button2.onclick = function() {
    modal.close();
}

searchButton.onclick = function(event) {
    event.preventDefault();
}
