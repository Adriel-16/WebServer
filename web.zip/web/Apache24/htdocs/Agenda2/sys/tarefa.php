<?php
session_name('iniciar');
session_start();

if (!isset($_SESSION['cadastro']) || $_SESSION['cadastro'] == false) {
    header("location: login.php");
    exit();
}

include('conect.php');
$obj = new conect();
$pdo = $obj->conectarBanco();

$idUsuario = $_SESSION['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['nova_tarefa'])) {
    $tarefa = htmlspecialchars($_POST['nova_tarefa']);
    $data_criacao = htmlspecialchars($_POST['data_criacao']);

    $sql = "INSERT INTO Tarefas (tarefa, concluida, data_criacao, idfk) VALUES (:tarefa, False, :data_criacao, :idfk)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':tarefa', $tarefa);
    $stmt->bindParam(':data_criacao', $data_criacao);
    $stmt->bindParam(':idfk', $idUsuario);
    $stmt->execute();
}

if (isset($_GET['concluir'])) {
    $idTarefa = intval($_GET['concluir']);
    $sql = "UPDATE Tarefas SET concluida = True WHERE id_tarefas = :idTarefa AND idfk = :idfk";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':idTarefa', $idTarefa, PDO::PARAM_INT);
    $stmt->bindParam(':idfk', $idUsuario, PDO::PARAM_INT);
    $stmt->execute();
}

if (isset($_GET['excluir'])) {
    $idTarefa = intval($_GET['excluir']);
    $sql = "DELETE FROM Tarefas WHERE id_tarefas = :idTarefa AND idfk = :idfk";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':idTarefa', $idTarefa, PDO::PARAM_INT);
    $stmt->bindParam(':idfk', $idUsuario, PDO::PARAM_INT);
    $stmt->execute();
}

$sql = "SELECT id_tarefas, tarefa, concluida, data_criacao FROM Tarefas WHERE idfk = :idfk ORDER BY data_criacao DESC";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':idfk', $idUsuario, PDO::PARAM_INT);
$stmt->execute();
$tarefas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSSagenda/tarefa.css">
    <title>Tarefas</title>

</head>
<body>
<header>
    <div class="iconeVoltar">
        <a href="AgendaContatosSelect.php"><button><i class='bx bx-home'></i></button></a>
    </div>
    <h1>Tarefas</h1>
</header>

<main>
    <form action="" method="POST" class="adicionar-tarefa">
        <input type="text" name="nova_tarefa" placeholder="Digite uma nova tarefa" required>
        <input type="date" name="data_criacao" required>
        <button type="submit">Adicionar</button>
    </form>

    <ul class="lista-tarefas">
        <?php if (!empty($tarefas)): ?>
            <?php foreach ($tarefas as $tarefa): ?>
                <li class="<?= $tarefa['concluida'] ? 'concluida' : '' ?>">
                    <div class="detalhes-tarefa">
                        <span class="texto-tarefa"><?= htmlspecialchars($tarefa['tarefa']) ?></span>
                        <span class="data-tarefa"><?= date('d/m/Y', strtotime($tarefa['data_criacao'])) ?></span>
                    </div>
                    <div class="acoes">
                        <?php if (!$tarefa['concluida']): ?>
                            <a href="?concluir=<?= $tarefa['id_tarefas'] ?>" class="btn-concluir">Concluir</a>
                        <?php endif; ?>
                        <a href="?excluir=<?= $tarefa['id_tarefas'] ?>" class="btn-excluir">Excluir</a>
                    </div>
                </li>
            <?php endforeach; ?>
        <?php else: ?>
            <li>Nenhuma tarefa encontrada.</li>
        <?php endif; ?>
    </ul>
</main>
</body>
</html>
