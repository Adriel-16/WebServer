<?php
    function escrever_log($mensagem) {
      
        $arquivo = 'sys/logs/log.txt';

        if (!is_dir('sys/logs')) {
            mkdir('sys/logs', 0777, true);
        }
        $log = fopen($arquivo, 'a');

        if ($log === false) {
            die('Não foi possível abrir o arquivo de log');
        }

        $data = date('Y-m-d H:i:s');

        fwrite($log, "[$data] - $mensagem\n");
        fclose($log);
    }
?>
