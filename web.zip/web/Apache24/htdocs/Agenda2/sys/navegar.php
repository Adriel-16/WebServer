<?php
session_start();

if ($_SESSION["logado"] == FALSE) {
    header("Location: ../index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/navegar.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda</title>
</head>
<body>
    <header>
        <div class="container">

            <div class="sair">
                <a href="logoff.php" name="sair">
                    <img src="css/img/logout.png" width="50px" alt="Sair">
                </a>
                <label for="sair">Sair</label>
            </div>

            <div class="add">
                <a href="contato.php">
                    <img src="css/img/add.png" height="70px" name="cntt">
                </a>
                <label for="cntt">Adicionar contato</label>
            </div>

            <div class="lista">
                <button id="listar" class="btao" name="lista"><img src="css/img/lista.png" height="70px" name="lista"></button>
                <label for="lista">Abrir Lista</label>
            </div>

            <dialog id="modal" open>
                <div class="container2">
                    <div class="pesquisar">
                        <form method="post" action="navegar.php">
                            <input type="text" class="pesquisarin" id="pesqusiarin" name="pesquisar2" placeholder="Pesquisar Contato">
                            <div class="botao_pesquisar">
                                <button id="btao2" class="btao2" type="submit" name="pesquisar3"><img src="css/img/lupa.png" height="30px" name="pesquisa"></button>
                            </div>
                        </form>
                        <a href="editar_perfil.php"><button class="editar_perfil">Editar perfil</button></a>

                        
                        <div class="botao_chat">
                            <a href="chat/chat.php"><button class="btao2" name="chat"><img src="css/img/chat.png" height="30px"></button></a>
                        </div>

                        <div class="botao_tarefa">
                            <a href="tarefa.php"><button class="btao2" name="tarefa"><img src="css/img/tarefas.png" height="30px"></button></a>
                        </div>

                        <div class="contatos">
                        <?php

                            extract($_POST);
                            if (isset($_POST['pesquisar3'])) {
                                include_once("class/connect.php");
                                $obj = new connect();
                                $resultado = $obj->conectarBanco();
                                $indice = 0;
                                $sql = "SELECT * FROM Contatos WHERE nome LIKE :pesquisa AND usuario_id = :usuario_id";
                                $query = $resultado->prepare($sql);
                                
                                $query->bindValue(':pesquisa', $_POST['pesquisar2'] . '%', PDO::PARAM_STR);
                                $query->bindValue(':usuario_id', $_SESSION["id"], PDO::PARAM_INT);
                                
                                if ($query->execute()) {
                                    while ($linha = $query->fetch(PDO::FETCH_ASSOC)) {
                                        $linhas[$indice] = $linha;
                                        $indice++;
                                    }
                                }
                                if ($indice > 0) {

                                    echo '<table class="table1">';
                                    echo '
                                                <tr>
                                                    <td style="color:black;">Nome</td>
                                                    <td style="color:black;">Telefone</td>
                                                    <td style="color:black;">Email</td>
                                                    <td style="color:black;">Endereço</td>
                                                </tr>
                                            ';
                                    for ($i = 0; $i < $indice; $i++) {

                                        // Verificar se a imagem existe antes de tentar exibi-la
                                        if (!empty($linhas[$i]['imagem'])) {
                                            $imageData = $linhas[$i]['imagem'];
                                        
                                            // Garantir que os dados sejam convertidos corretamente
                                            if (is_resource($imageData)) {
                                                $imageData = stream_get_contents($imageData);
                                            }
                                        
                                            // Converter o binário para base64
                                            $imageBase64 = base64_encode($imageData);
                                            $imageSrc = "data:image/jpg;base64," . $imageBase64;
                                        } else {
                                            // Caso a imagem não exista no banco, usa a imagem padrão
                                            $imageSrc = "css/img_perfil/default.jpeg";
                                        }
                                        

                                        echo '
                                                    <tr>
                                                        <td style="border-right: 2px solid black;">' . $linhas[$i]['nome'] . '</td>
                                                        <td style="border-right: 2px solid black;">' . $linhas[$i]['telefone'] . '</td>
                                                        <td style="border-right: 2px solid black;">' . $linhas[$i]['email'] . '</td>
                                                        <td style="border-right: 2px solid black;">' . $linhas[$i]['endereco'] . '</td>
                                                        <td>
                                                            <form action="delete.php" method="POST">
                                                                <input type="hidden" name="id_cont" value="' . $linhas[$i]['id_cont'] . '">
                                                                <input type="submit" name="delete" value="delete">
                                                            </form>
                                                        </td>
                                                        <td>
                                                            <a href="editar.php?id_cont=' . $linhas[$i]['id_cont'] . '"><input type="button" name="editar" value="editar"></a>
                                                        </td>
                                                    </tr>
                                                ';
                                    }
                                    echo "</table>";
                                } else {
                                    echo "Nenhum contato encontrado.";
                                }
                            }
                            ?>
                        </div>
                    </div>
                    <div class="fechar">
                        <button id="fechar2" class="btao3">Fechar lista</button>
                    </div>
                </div>
            </dialog>

        </div>
    </header>
</body>
<script src="js/listar.js"></script>
</html>
