<?php

session_start();

if ($_SESSION["logado"] == FALSE) {
    header("Location: ../index.php");
    exit();
}
include_once("class/connect.php");
$obj = new connect();
$resultado = $obj->conectarBanco();

$id = $_GET['id'];
$indice = 0;
$sql = "SELECT * FROM Usuario WHERE id = ".$id.";";
$query = $resultado->prepare($sql);

if($query->execute()) {
    while($linha = $query->fetch(PDO::FETCH_ASSOC)) {
        $linhas[$indice] = $linha;
        $indice++;  
    }

    $nome = $linhas[0]['nome'];
    $email = $linhas[0]['email'];
    $login = $linhas[0]['login'];

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/editar.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edição de usuário</title>
</head>
<body>

<div class="fundo">
    <div class="sair">
        <a href="navegar.php" name="sair">
            <img src="css/img/voltar.png" width="50px" alt="Sair">
        </a>
        <label for="sair">Voltar</label>
    </div>
    
    <form action="editar_usuario.php?id_usuario=<?=$_GET['id_usuario'];?>" method="post" enctype="multipart/form-data">
        <div class="tabela">
            <div class="login2">
                <h1>Editar Usuário</h1>
            </div>
            <table>
                <tr>
                    <td><input type="text" id="nome" name="nome" value="<?=$linhas[0]['nome']?>" required placeholder="  Nome"></td>
                </tr>
                <tr>
                    <td><input type="email" id="email" name="email" value="<?=$linhas[0]['email']?>" required placeholder="  Email"></td>
                </tr>
                <tr>
                    <td><input type="text" id="login" name="login" value="<?=$linhas[0]['login']?>" required placeholder="  Login"></td>
                </tr>
            </table>
        </div>
        <div class="botao">
            <table>
                <tr>
                    <td><button id="button" type="submit" name="editar" value="editar">Editar</button></td>
                </tr>
            </table>
        </div>
    </form>
</div>
</body>
</html>

<?php

if(isset($_POST["editar"])) {
    $nome = $_POST['name'];
    $email = $_POST['email'];


    $sqlUpdate = "UPDATE Contatos SET nome = '".$nome."', email = '".$email."', telefone = '".$telefone."', endereco = '".$endereco."' WHERE id_cont = ".$id.";";
    $query = $resultado->prepare($sqlUpdate);

    if($query->execute()) {
        echo '<script type="text/javascript">alert("Edição feita com sucesso!");</script>';
    }

    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
        $imagem = file_get_contents($_FILES['foto']['tmp_name']);
        
        $sqlUpdateImage = "UPDATE Contatos SET imagem = :imagem WHERE id_cont = :id_cont";
        $queryImage = $resultado->prepare($sqlUpdateImage);
        $queryImage->bindParam(':imagem', $imagem, PDO::PARAM_LOB);
        $queryImage->bindParam(':id_cont', $id, PDO::PARAM_INT);

        if ($queryImage->execute()) {
            echo '<script type="text/javascript">alert("contato atualizado com sucesso!");</script>';
        } else {
            echo '<script type="text/javascript">alert("Erro ao atualizar contato!");</script>';
        }
    }
}
?>


