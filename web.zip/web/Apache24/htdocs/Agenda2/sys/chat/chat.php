<html lang="pt-BR">
<head>
    <link rel="stylesheet" href="css/chat.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat</title>
	<script type="text/javascript">

		function ajax() {
    var req = new XMLHttpRequest();
    req.onreadystatechange = function() {
        if (req.readyState == 4 && req.status == 200) {
            document.getElementById('chat').innerHTML = req.responseText;
        }
    }
    req.open('GET', 'refresh.php', true); // Certifique-se de que o caminho está correto
    req.send();
}

setInterval(function(){ajax();},1000);

	</script>
	<div class="chat" id="chat" style="border:solid black 1px;">
	</div>
</head>
<body>
	
	<form action="chat.php" method="post">
        <div class="inputs">
            <input type="text" id="name" name="name" required placeholder="Nome">  
            <br /><br />
            <input type="text" id="msg" name="msg" required placeholder="Sua mensagem aqui"> <br><br>
            <button id="button" type="submit" name="Enviar">Enviar</button>
        </div>
	</form>
    <a href="../navegar.php" class="link"><button syle="color:black">Voltar</button></a>
</body>
</html>		
<?php

	extract($_POST);
    if(isset($_POST["Enviar"]))
    {
        include_once("../class/connect.php");
        $obj = new connect();
        $resultado = $obj->conectarBanco();
		
		$sql = "INSERT INTO Chat (nome, msg) VALUES ('".$_POST['name']."','".$_POST['msg']."') ;";

        $query = $resultado->prepare($sql);
        $indice = 0;
        if($query->execute())
        {
			 $_POST = [];
			 header('Location: chat.php');
			 exit();
		}
	}
?>