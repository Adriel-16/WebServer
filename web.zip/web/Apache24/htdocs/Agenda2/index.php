<?php
session_start();

// Verifica se o formulário foi enviado
if (isset($_POST["btnLogin"])) {
    // Inclui a classe de conexão ao banco de dados
    include_once("sys/class/connect.php");
    // Inclui a função de log
    include_once("sys/logs/log.php");

    // Cria uma instância do objeto de conexão
    $obj = new connect();
    $resultado = $obj->conectarBanco();

    // Criptografa os dados do usuário
    $nomeUsuario = md5($_POST["name"]);
    $usuariocriptografado = md5($_POST["passwrd"]);

    // Prepara a consulta para buscar o usuário no banco
    $sql = "SELECT * FROM Usuario WHERE login = :login AND passwrd = :senha;";
    $query = $resultado->prepare($sql);
    $query->bindValue(':login', $nomeUsuario, PDO::PARAM_STR);
    $query->bindValue(':senha', $usuariocriptografado, PDO::PARAM_STR);

    $indice = 0;

    // Executa a consulta
    if ($query->execute()) {
        while ($linha = $query->fetch(PDO::FETCH_ASSOC)) {
            $linhas[$indice] = $linha;
            $indice++;
        }

        if ($indice == 1) {
            // Login bem-sucedido
            $_SESSION["logado"] = TRUE;
            $_SESSION["id"] = $linhas[0]['id'];
            escrever_log("Usuário {$_POST['name']} logado com sucesso.");
            header("Location: sys/navegar.php");
            exit();
        } else if ($indice == 0) {
            // Login falhou
            escrever_log("Tentativa de login falha para o usuário {$_POST['name']}. Usuário ou senha incorretos.");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/login.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
<form action="index.php" method="post">
    <div class="container">
        <div class="login">
            <div class="login2">
                <h1>LOGIN</h1>
            </div>
            <table>
                <tr>
                    <td><input type="text" name="name" placeholder="  Nome de Login:"></td>
                </tr>
                <tr>
                    <td><input type="password" name="passwrd" placeholder="  Senha:"></td>
                </tr>
            </table>
            <div class="botoes">
                <table>
                    <tr>
                        <td><button class="login2" name="btnLogin" type="submit">Login</button></td>
                    </tr>
                </table>
                <div class="cadastro">
                    <a href="sys/cadastro.php"><button type="button" class="cadastro" name="cad">Cadastre-se</button></a>
                </div>
            </div>
        </div>
    </div>
</form>
</body>
</html>
